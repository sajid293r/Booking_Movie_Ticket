import classes from "./HomePage.module.css";
import MoviesData from "../../store/MoviesData";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import { vipActions } from "../../store/storeOne";

const HomePage = () => {
    const history = useNavigate();
    const dispatch = useDispatch();

    const movieClickHandler = (movieName) => {
        history("/booking")
        dispatch(vipActions.updateName(movieName));
    }


    const movieCards = MoviesData.map((item, index) => {
        return (
            <div onClick={() => movieClickHandler(item.Title)} key={index}>
                <img src={item.Poster} alt="" />
                <h4>{item.Title}</h4>
                <p>{item.Released}</p>

            </div>
        )
    })

    return (
        <main className={classes.cards}>
            {movieCards}
        </main>
    )
}

export default HomePage;