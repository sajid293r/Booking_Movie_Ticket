import SectionOne from "./components/sections/SectionOne";
import SectionTwo from "./components/sections/SectionTwo";
import SectionThree from "./components/sections/SectionThree";
import HomePage from "./components/homePage/HomePage";
import Header from "./components/header/Header";
import Checkout from "./components/checkout/Checkout";
import CheckoutButton from "./components/checkout/CheckoutButton";
import { BrowserRouter,Routes, Route } from "react-router-dom";
import './App.css';

const App = () => {
  return (
    <BrowserRouter> 
      <Routes>
      <Route path="/" element={<HomePage />}/>
      <Route path="/booking" element={<Header />}/>
        <Route path="/sectionone" element={<SectionOne />}/>
        <Route path="/sectiontwo" element={<SectionTwo />}/>
        <Route path="/sectionthree" element={<SectionThree />}/>
        <Route path="/checkoutbutton" element={<CheckoutButton />}/>
      <Route path="/checkout" element={<Checkout />}/>
      </Routes>
    </BrowserRouter>
  )
};
export default App;
